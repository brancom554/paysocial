<div id="section_prod_square">
	<div class="container">
    	<div class="row">
        	<div id="title_section">{%mostviewed_title%}</div>
        </div>
        
        <div>{%mostviewed_ads_top%}</div>
    	
        <div class="row">
			{%mostviewed_products%}        	
        </div>
        
        <div>{%mostviewed_ads_bottom%}</div>
        
    </div>
</div>