<script> var msg_error_conection = '<?php echo $this->page->lang('general_txt_cannotperform');?>'; </script>
<div id="top-login">
	<div class="container">
    	<div class="row">
        	<div class="col-xs-12">
				<div id="logo"><a href="<?php echo $K->SITE_URL?>"><img src="{%logo_top%}"></a></div>
            </div>
        </div>
    	
    </div>
</div>