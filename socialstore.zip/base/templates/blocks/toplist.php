<div id="section_prod_square">
	<div class="container">
    	<div class="row">
        	<div id="title_section_top">{%toplist_title%}</div>
        </div>
        
        <div>{%toplist_ads_top%}</div>
    	
        <div class="row">
			{%toplist_products%}        	
        </div>
        
        <div>{%toplist_ads_bottom%}</div>
        
    </div>
</div>