<tr>
	<th class="center"><?php echo $this->lang('products_lists_table_name'); ?></th>
    <th class="center"><?php echo $this->lang('products_lists_table_paywith'); ?></th>
    <th class="center"><?php echo $this->lang('products_lists_table_views'); ?></th>
    <th class="center"><?php echo $this->lang('products_lists_table_downloads'); ?><br><span class="txtsimple"><?php echo $this->lang('products_lists_table_orshowlink'); ?></span></th>
</tr>