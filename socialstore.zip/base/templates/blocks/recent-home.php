<div id="home_block_recent_prod">
	<div class="container">
    	<div class="row">
        	<div id="title_block">{%home_title_recent%}</div>
        </div>
        
        <div>{%home_ads_top%}</div>
        
        <div class="row">
			{%home_recent_products%}
        </div>
        
        <div>{%home_ads_bottom%}</div>
        
    </div>
</div>