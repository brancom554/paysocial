<div id="area-admin-block">
	<div class="container">
    	<div class="row">
        	<div id="bar-left" class="col-xs-4 col-sm-3 col-md-2">
            	<div>{%admin_menu%}</div>
            </div>
        	<div id="area-info" class="col-xs-8 col-sm-9 col-md-10">
            	<div>{%admin_body%}</div>
            </div>
        </div>
    
    </div>
</div>