{%code_js_init%}

<div id="top-home">

	{%top_home_info%}
    
    <div class="clear"></div>
    
</div>

<div class="clear"></div>