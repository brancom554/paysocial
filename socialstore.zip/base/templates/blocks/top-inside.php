<div id="top-inside" class="the-borde-bottom">
    {%info_top_inside%}
</div>