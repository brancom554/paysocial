<div id="foot">
	{%foot_info%}
</div>