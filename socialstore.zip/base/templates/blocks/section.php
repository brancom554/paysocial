<div id="area-section">
	<div id="bar-header-section">
    	<div class="container">
        	<div class="row">
            	<div class="col-xs-12"><h1>{%section_title_bar%}</h1></div>
            </div>
        </div>
    </div>
	<div id="html-section">
    	<div class="container">
        	<div class="row">
            	<div class="col-xs-12">{%section_text_html%}</div>
            </div>
        </div>
    </div>
</div>