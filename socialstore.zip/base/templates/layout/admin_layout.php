    <div id="admin-top-area">
		{%top_content_top%}
		{%top_content%}
		{%top_content_bottom%}    
    </div>
    
    <div id="admin-main-area">
        {%main_content_top%}
        {%main_content%}
        {%main_content_bottom%}        
    </div>
    
    <div id="admin-foot-area">
		{%foot_content_top%}
		{%foot_content%}
		{%foot_content_bottom%}    
    </div>