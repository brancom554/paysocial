<!DOCTYPE html>
<html lang="{%html_lang_abbrv%}" {%html_class%}>
<head>
    <title>{%page_title%}</title>
	<meta http-equiv="cleartype" content="on">
	<meta name="HandheldFriendly" content="True">
	<meta name="MobileOptimized" content="320">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    {%header_data%}
</head>
<body {%body_class%}>
<div id="wrapper">