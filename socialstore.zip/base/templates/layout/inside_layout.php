    <div id="inside-top-area">
		{%top_content_top%}
		{%top_content%}
		{%top_content_bottom%}    
    </div>
    
    <div id="inside-main-area">
        {%main_content_top%}
        {%main_content%}
        {%main_content_bottom%}        
    </div>
    
    <div id="inside-foot-area">
		{%foot_content_top%}
		{%foot_content%}
		{%foot_content_bottom%}    
    </div>