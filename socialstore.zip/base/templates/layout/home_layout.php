    <div id="home-top-area">
		{%top_content_top%}
		{%top_content%}
		{%top_content_bottom%}    
    </div>
    
    <div id="home-main-area">
        {%main_content_top%}
        {%main_content%}
        {%main_content_bottom%}
    </div>
    
    <div id="home-foot-area">
		{%foot_content_top%}
		{%foot_content%}
		{%foot_content_bottom%}    
    </div>