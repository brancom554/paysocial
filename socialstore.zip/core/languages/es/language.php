<?php
	$current_language = (object) array (
		'name' => 'Español',
		'php_timezone' => 'Europe/Madrid',
		'php_locale' => 'es_ES.UTF-8',
		'author_name' => 'Koyllur Developer',
		'author_url' => 'http://www.koyllur.com',
	);	
?>